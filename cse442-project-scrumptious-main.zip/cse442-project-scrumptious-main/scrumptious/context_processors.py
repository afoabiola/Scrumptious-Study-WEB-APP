from scrumptious.settings import cheshire_prefix


def base(_):
    return {'BASE_URL': cheshire_prefix('')[:-2]}
