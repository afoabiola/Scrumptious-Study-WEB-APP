# Building.objects.get(name='Baldy Hall')
import unittest

from django.contrib.auth.models import User
from django.db import IntegrityError
from django.test import TestCase

from scrumptious.form import CustomUserCreationForm


class TestRegistration(TestCase):

    def test_username(self):
        form = CustomUserCreationForm(data={
            'username': 'test_username',
            'email': 'unitTest@example.com',
            'password1': 'university',
            'password2': 'university'
        })
        form2 = CustomUserCreationForm(data={
            'username': 'test_username2',
            'email': 'unitTest2@example.com',
            'password1': 'university2',
            'password2': 'university2'
        })
        assert form.is_valid()
        form.save()
        assert form2.is_valid()
        form2.save()
        all_users = User.objects.all()
        print all_users
        self.assertEqual("test_username", all_users[0].username)
        self.assertEqual("test_username2", all_users[1].username)
        print all_users[0].username

    def test_save_user_twice(self):
        form1 = CustomUserCreationForm(data={
            'username': 'test_username',
            'email': 'unitTest@example.com',
            'password1': 'university',
            'password2': 'university'
        })
        assert form1.is_valid()
        form1.save()
        try:
            form1.save()
            self.fail('Integrity Error should\'ve been thrown!')
        except IntegrityError:
            pass

    def test_password_match(self):
        form1 = CustomUserCreationForm(data={
            'username': 'test_username',
            'email': 'unitTest@example.com',
            'password1': 'university',
            'password2': 'university'
        })

        form2 = CustomUserCreationForm(data={
            'username': 'test_username',
            'email': 'unitTest@example.com',
            'password1': 'university',
            'password2': 'college'
        })

        assert form1.is_valid()
        form1.save()
        self.assertRaises(form2.is_valid())
        all_users = User.objects.all()
        self.assertEqual("university", "university")
        self.assertNotEqual("university", "college")



    def test_empty_invalid_user(self):
        form1 = CustomUserCreationForm(data={
            'username': ' ',
            'email': ' ',
            'password1': ' ',
            'password2': ' '
        })
        form1.is_valid

        try:
            form1.save()
            self.fail('Error should\'ve been thrown!')
        except:
            pass


if __name__ == '__main__':
    unittest.main()
