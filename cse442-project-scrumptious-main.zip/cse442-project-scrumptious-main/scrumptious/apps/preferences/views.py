# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from typing import List

from .forms import PreferencesForm
from .models import UserPreferences, Building


@login_required
def user_preferences_view(request):
    if request.method == 'POST':
        form = PreferencesForm(request.POST)
        form.save_user_preferences(request.user)
    else:
        user_preferences = UserPreferences.objects.get_or_create(user=request.user)[0]  # type: UserPreferences
        user_buildings = user_preferences.buildings.all()  # type: List[Building]

        initial = {
            'prefers_libraries': user_preferences.prefers_libraries,
            'prefers_obscure_spaces': user_preferences.prefers_obscure_spaces,
            'prefers_silent_spaces': user_preferences.prefers_silent_spaces,
            'buildings': user_buildings
        }

        form = PreferencesForm(initial=initial)

    return render(request, 'preferences.html', {'form': form})


@login_required
def delete_view(request):
    username = request.user
    request.user.delete()
    return render(request, 'delete.html', {'username': username})
