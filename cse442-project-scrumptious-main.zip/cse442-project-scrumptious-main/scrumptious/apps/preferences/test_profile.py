# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.models import User
from django.test import TestCase

from scrumptious.apps.preferences.models import Building, UserPreferences
from .forms import PreferencesForm


# Create your tests here.

class TestProfile_Normal(TestCase):

    # testing with multiple users or single user - PASSED

    # testing normal case - PASSED
    # testing when preferences empty but buildings not empty - PASSED
    # testing when all fields filled - PASSED

    def test_user_normal(self):

        # making the user
        user = User.objects.create_user(username='test_user', email='test_email', password='12345')
        # the buildings the user wants
        buildings_selected = [Building.objects.get(name='Capen Hall'), Building.objects.get(name='Cooke Hall')]
        # making the user's form
        form = PreferencesForm(data={'prefers_libraries': True,
                                     'prefers_obscure_spaces': None,
                                     'prefers_silent_spaces': True,
                                     'buildings': buildings_selected})
        # check if form is valid entry
        assert form.is_valid()
        # save the preferences made in the form to the user
        form.save_user_preferences(user)
        # get the user's data
        u_p = UserPreferences.objects.get(user=user)
        user_buildings = u_p.buildings.all()
        expected = ['Capen Hall', 'Cooke Hall']

        print "[TEST #1 - NORMAL CASE]"

        # check it with expected
        self.assertEqual(u_p.prefers_libraries, True)
        print u_p.prefers_libraries
        self.assertEqual(u_p.prefers_silent_spaces, True)
        print u_p.prefers_silent_spaces
        self.assertEqual(u_p.prefers_obscure_spaces, False)
        print u_p.prefers_obscure_spaces

        for i, j in zip(user_buildings, expected):
            self.assertEqual(i.name, j)
            print i.name

        user2 = User.objects.create_user(username='test_user2', email='test_email2', password='123452')

        buildings_selected2 = [Building.objects.get(name='Capen Hall')]

        # making the user's form
        form2 = PreferencesForm(data={'prefers_libraries': None,
                                      'prefers_obscure_spaces': None,
                                      'prefers_silent_spaces': None,
                                      'buildings': buildings_selected2})
        assert form2.is_valid()
        # save form to user
        form2.save_user_preferences(user2)
        # get user's data after saving it
        u_p2 = UserPreferences.objects.get(user=user2)
        user_buildings2 = u_p2.buildings.all()

        print "[TEST #2 - PREFERENCES EMPTY/BUILDINGS NOT EMPTY]"

        # check it with expected
        expected2 = ['Capen Hall']
        # 'Capen Hall'
        self.assertEqual(u_p2.prefers_libraries, False)
        print u_p2.prefers_libraries
        self.assertEqual(u_p2.prefers_silent_spaces, False)
        print u_p2.prefers_silent_spaces
        self.assertEqual(u_p2.prefers_obscure_spaces, False)
        print u_p2.prefers_obscure_spaces

        for i, j in zip(user_buildings2, expected2):
            self.assertEqual(i.name, j)
            print i.name

        user3 = User.objects.create_user(username='test_user3', email='test_email3', password='123453')
        buildings_selected3 = [Building.objects.get(name='Capen Hall'),
                               Building.objects.get(name='Cooke Hall'),
                               Building.objects.get(name='Alumni Arena'),
                               Building.objects.get(name='Baldy Hall'),
                               Building.objects.get(name='Bell Hall'),
                               Building.objects.get(name='Bonner Hall'),
                               Building.objects.get(name='Center for the Arts'),
                               Building.objects.get(name='Crofts Hall'),
                               Building.objects.get(name='Davis Hall'),
                               Building.objects.get(name='Ellicott Complex'),
                               Building.objects.get(name='Fronczak Hall'),
                               Building.objects.get(name='Furnas Hall'),
                               Building.objects.get(name='Hochstetter Hall'),
                               Building.objects.get(name='Jacobs Management Center'),
                               Building.objects.get(name='Jarvis Hall'),
                               Building.objects.get(name='Ketter Hall'),
                               Building.objects.get(name='Knox Lecture Hall'),
                               Building.objects.get(name='Lockwood Library'),
                               Building.objects.get(name='Mathematics Building'),
                               Building.objects.get(name='Natural Sciences Complex'),
                               Building.objects.get(name='Norton Hall'),
                               Building.objects.get(name='Park Hall'),
                               Building.objects.get(name='Slee Hall'),
                               Building.objects.get(name='Student Union'),
                               Building.objects.get(name='Talbert Hall'),
                               Building.objects.get(name='O\'Brian Hall')]
        # making the user's form
        form3 = PreferencesForm(data={'prefers_libraries': True,
                                      'prefers_obscure_spaces': True,
                                      'prefers_silent_spaces': True,
                                      'buildings': buildings_selected3})
        assert form3.is_valid()
        # save user's data
        form3.save_user_preferences(user3)
        # get user's saved data
        u_p3 = UserPreferences.objects.get(user=user3)
        user_buildings3 = u_p3.buildings.all()

        print "[TEST #3 - ALL FILLED]"

        expected3 = ['Alumni Arena', 'Baldy Hall', 'Bell Hall', 'Bonner Hall', 'Capen Hall', 'Center for the Arts',
                     'Cooke Hall', 'Crofts Hall', 'Davis Hall', 'Ellicott Complex', 'Fronczak Hall', 'Furnas Hall',
                     'Hochstetter Hall', 'Jacobs Management Center', 'Jarvis Hall', 'Ketter Hall', 'Knox Lecture Hall',
                     'Lockwood Library', 'Mathematics Building', 'Natural Sciences Complex', 'Norton Hall',
                     'Park Hall', 'Slee Hall', 'O\'Brian Hall', 'Student Union', 'Talbert Hall']

        self.assertEqual(u_p3.prefers_libraries, True)
        print u_p3.prefers_libraries
        self.assertEqual(u_p3.prefers_silent_spaces, True)
        print u_p3.prefers_silent_spaces
        self.assertEqual(u_p3.prefers_obscure_spaces, True)
        print u_p3.prefers_obscure_spaces

        # for i, j in zip(user_buildings3, expected3):
        #     self.assertEqual(i.building.name, j)
        #     print i.building.name

        for i in user_buildings3:
            print i.name
            assert i.name in expected3

# class TestProfile_Empty(TestCase):
#
#     # *****have to work on THIS ONE
#     def test_profile_empty(self):
#         user2 = User.objects.create_user(username='test_user2', email='test_email2', password='123452')
#
#         buildings_selected2 = [Building.objects.get(name='Capen Hall')]
#
#         # Building.objects.get(name='Capen Hall')
#         # making the user's form
#         form2 = PreferencesForm(data={'prefers_libraries': None,
#                                       'prefers_obscure_spaces': None,
#                                       'prefers_silent_spaces': None,
#                                       })
#         assert form2.is_valid()
#         # save form to user
#         form2.save_user_preferences(user2)
#         # get user's data after saving it
#         u_p2 = UserPreferences.objects.get(user=user2)
#         # user_buildings2 = UserBuildings.objects.filter(user=user2)
#
#         print "[TEST #2 - PREFERENCES EMPTY/BUILDINGS NOT EMPTY]"
#
#         # check it with expected
#         expected2 = ['Capen Hall']
#         # 'Capen Hall'
#         self.assertEqual(u_p2.prefers_libraries, None)
#         print u_p2.prefers_libraries
#         self.assertEqual(u_p2.prefers_silent_spaces, None)
#         print u_p2.prefers_silent_spaces
#         self.assertEqual(u_p2.prefers_obscure_spaces, None)
#         print u_p2.prefers_obscure_spaces
#
#         # for i,j in zip(user_buildings2, expected2):
#         #     self.assertEqual(i.building.name, j)
#         #     print i.building.name


# def test_profile_all_preferred(self):
#
#     user2 = User.objects.create_user(username='test_user2',email='test_email2',password='123452')
#
#     #all_buildings = Building.object.all()
#
#     buildings_input = []
#
#
#
#
#
#     #making the user's form
#     form = PreferencesForm(data={'prefers_libraries': True,
#                                  'prefers_obscure_spaces' : True,
#                                  'prefers_silent_spaces': True,
#                                  'buildings': buildings_input})
#     #check if form is valid entry
#     assert form.is_valid()
#
#     #save the preferences made in the form to the user
#     form.save_user_preferences(user2)
#
#
#     #get the user's data
#     u_p = UserPreferences.objects.get(user=user2)
#     user_buildings = UserBuildings.objects.filter(user=user2)
#
#     expected = ['Alumni Arena', 'Baldy Hall', 'Bell Hall', 'Bonner Hall', 'Capen Hall', 'Center for the Arts',
#                 'Cooke Hall', 'Crofts Hall', 'Davis Hall', 'Ellicott Complex', 'Fronczak Hall', 'Furnas Hall',
#                 'Hochstetter Hall', 'Jacobs Management Center', 'Jarvis Hall', 'Ketter Hall', 'Knox Lecture Hall',
#                 'Lockwood Library', 'Mathematics Building', 'Natural Sciences Complex', 'Norton Hall',
#                 'O’Brian Hall', 'Park Hall', 'Slee Hall', 'Student Union', 'Talbert Hall']
#
#
#     print "[TEST #3]"
#
#     #check it with expected
#     self.assertEqual(u_p.prefers_libraries, True)
#     print u_p.prefers_libraries
#     self.assertEqual(u_p.prefers_silent_spaces, True)
#     print u_p.prefers_silent_spaces
#     self.assertEqual(u_p.prefers_obscure_spaces, True)
#     print u_p.prefers_obscure_spaces
#
#     for i,j in zip(user_buildings, expected):
#         self.assertEqual(i.building.name, j)
#         print i.building.name
