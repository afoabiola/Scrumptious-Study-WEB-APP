# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.models import User
from django.db import models


class Campus(models.Model):
    name = models.CharField(max_length=100)


class Building(models.Model):
    name = models.CharField(max_length=100)
    campus = models.ForeignKey(Campus)


class UserPreferences(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, unique=True)
    prefers_libraries = models.BooleanField(default=True)
    prefers_obscure_spaces = models.BooleanField(default=False)
    prefers_silent_spaces = models.BooleanField(default=True)
    buildings = models.ManyToManyField(Building)
