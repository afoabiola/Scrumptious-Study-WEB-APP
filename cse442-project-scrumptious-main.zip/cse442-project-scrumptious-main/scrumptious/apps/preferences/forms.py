# -*- coding: utf-8 -*-
from django import forms
from django.contrib.auth.models import User
from typing import List

from scrumptious.apps.preferences.models import Building, UserPreferences


class NamedModelMultipleChoiceField(forms.ModelMultipleChoiceField):
    widget = forms.CheckboxSelectMultiple

    def label_from_instance(self, obj):
        return obj.name


class PreferencesForm(forms.Form):
    prefers_libraries = forms.BooleanField(required=False)
    prefers_obscure_spaces = forms.BooleanField(required=False)
    prefers_silent_spaces = forms.BooleanField(required=False)
    buildings = NamedModelMultipleChoiceField(queryset=Building.objects.all())

    def save_user_preferences(self, user):
        # type: (User) -> None

        self.is_valid()
        user_preferences = UserPreferences.objects.get_or_create(user=user)[0]  # type: UserPreferences

        user_preferences.prefers_libraries = self.cleaned_data.get('prefers_libraries')
        user_preferences.prefers_obscure_spaces = self.cleaned_data.get('prefers_obscure_spaces')
        user_preferences.prefers_silent_spaces = self.cleaned_data.get('prefers_silent_spaces')

        buildings = self.cleaned_data.get('buildings', [])  # type: List[Building]
        user_preferences.buildings.set(buildings)

        user_preferences.save()
