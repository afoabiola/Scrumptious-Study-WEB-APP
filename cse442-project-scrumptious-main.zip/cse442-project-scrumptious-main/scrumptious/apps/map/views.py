# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.http.response import JsonResponse
from django.shortcuts import render

from scrumptious.apps.spaces.context_processors import space_base
from scrumptious.apps.spaces.models import StudySpace


def map_view(request):
    return render(request, 'map.html')


def map_data(request):
    spaces = [{
        'name': s.name,
        'url': space_base(None)['SPACE_BASE'] + '/' + s.slug,
        'geo': s.geo
    } for s in StudySpace.objects.all()]
    return JsonResponse(spaces, safe=False)
