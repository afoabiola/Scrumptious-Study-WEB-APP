# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import datetime

import pytz
from django.contrib.auth.models import User
from django.db import models
from django.db.models import Avg

from scrumptious.apps.preferences.models import Building


class FeatureManager(models.Manager):
    def library(self):
        return self.get(name='Library')

    def silent(self):
        return self.get(name='Silent Study')

    def obscure(self):
        return self.get(name='Unofficial/Obscure Space')


class Feature(models.Model):
    """
    Model to represent features a study space can have.
    """
    name = models.CharField(max_length=100, unique=True)
    objects = FeatureManager()


class StudySpace(models.Model):
    """
    Model to represent a study space.
    """
    name = models.CharField(max_length=100)
    # Slug used in the URL to refer to the study space (better than iterable ID numbers)
    slug = models.SlugField(max_length=20, unique=True)
    description = models.CharField(max_length=512)
    # URL to a photo of the space, likely within the site static
    picture = models.CharField(max_length=100)
    # Features belonging to a study space
    features = models.ManyToManyField(Feature)
    # (Optional) building the study space belongs to
    building = models.ForeignKey(Building, null=True)
    # Location, ideally would be PointField but GeoDjango is next to impossible to get working on Cheshire
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)

    @property
    def average_stars(self):
        return str(Review.objects.filter(study_space=self).aggregate(Avg('stars'))['stars__avg'] or 'No') + ' stars'

    @property
    def geo(self):
        return (self.latitude, self.longitude) if self.latitude and self.longitude else None

    @property
    def is_library(self):
        return Feature.objects.library() in self.features.all()

    @property
    def is_silent(self):
        return Feature.objects.silent() in self.features.all()

    @property
    def is_obscure(self):
        return Feature.objects.obscure() in self.features.all()

    @property
    def times(self):
        flat_days_of_week = [day[0] for day in StudySpaceTimes.DAYS_OF_WEEK]
        return sorted(StudySpaceTimes.objects.filter(study_space=self),
                      key=lambda t: (flat_days_of_week.index(t.day_of_week), t.start_time))

    @property
    def is_open(self):
        tz = pytz.timezone("America/New_York")
        now = datetime.datetime.now(tz).time()
        return StudySpaceTimes.objects.filter(study_space=self, start_time__lte=now, end_time__gte=now).exists()


class StudySpaceTimes(models.Model):
    """
    Model to represent times a study space is open.
    """
    DAYS_OF_WEEK = (
        ('MON', 'Monday'),
        ('TUE', 'Tuesday'),
        ('WED', 'Wednesday'),
        ('THR', 'Thursday'),
        ('FRI', 'Friday'),
        ('SAT', 'Saturday'),
        ('SUN', 'Sunday'),
    )
    study_space = models.ForeignKey(StudySpace)
    day_of_week = models.CharField(max_length=3, choices=DAYS_OF_WEEK)
    start_time = models.TimeField()
    end_time = models.TimeField()

    @property
    def ends_near_midnight(self):
        return self.end_time > datetime.datetime.strptime('23:59', '%H:%M').time()


class Review(models.Model):
    """
    Model to represent a review made by a user.
    """
    # The max length a review can be
    MAX_MESSAGE_LENGTH = 1024
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    study_space = models.ForeignKey(StudySpace)
    stars = models.SmallIntegerField()
    message = models.CharField(max_length=MAX_MESSAGE_LENGTH)

    class Meta:
        # Users can only have one review for a study space
        unique_together = ['user', 'study_space']
