# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from .forms import SpaceReviewForm, SpaceSearchForm, space_search_suggestions
from .models import StudySpace, Review
from .search import search_study_spaces
from ..preferences.models import UserPreferences


def home_view(request):
    spaces = StudySpace.objects.order_by('name').all()

    return render(request, 'home.html', {'spaces': spaces})


def location_search(request):
    user = (request.user if request.user.is_authenticated else None)
    preferences = UserPreferences.objects.get_or_create(user=user)[0]

    query = None
    geo = None
    if request.method == 'GET':
        form = SpaceSearchForm(request.GET)
        query = form.get_query()
        geo = form.get_geo()
    else:
        form = SpaceSearchForm()

    spaces = search_study_spaces(preferences, query, geo)

    return render(request, "location_search.html",
                  {'spaces': spaces, 'form': form, 'suggestions': space_search_suggestions()})


def space_view(request, slug):
    space = StudySpace.objects.get(slug=slug)

    return render(request, 'space.html', {'space': space})


@login_required
def space_review_view(request, slug):
    space = StudySpace.objects.get(slug=slug)

    if request.method == 'POST':
        form = SpaceReviewForm(request.POST)
        form.save_or_update_review(request.user, space)
    else:
        try:
            user_review = Review.objects.get(user=request.user, study_space=space)
            initial = {
                'stars': user_review.stars,
                'message': user_review.message
            }
        except Review.DoesNotExist:
            initial = {}

        form = SpaceReviewForm(initial=initial)

    return render(request, 'review.html', {'space': space, 'form': form})
