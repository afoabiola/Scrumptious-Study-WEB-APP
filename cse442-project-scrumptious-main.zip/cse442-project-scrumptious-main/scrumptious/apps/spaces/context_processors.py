from scrumptious.settings import cheshire_prefix


def space_base(_):
    return {'SPACE_BASE': cheshire_prefix('space')[:-1]}
