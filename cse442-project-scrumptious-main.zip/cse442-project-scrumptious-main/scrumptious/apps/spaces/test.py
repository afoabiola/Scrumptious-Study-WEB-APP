# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.models import User
from django.test import TestCase

import search
from scrumptious.apps.preferences.forms import PreferencesForm
from scrumptious.apps.preferences.models import Building, UserPreferences
from scrumptious.apps.spaces.models import Review, StudySpace
from .forms import SpaceReviewForm


# Create your tests here.

class Test_Review(TestCase):

    def test_review(self):
        # making the user
        user = User.objects.create_user(username='test_user', email='test_email', password='123456')

        test_study_space = StudySpace.objects.get(slug='5th-floor-lockwood')

        # make form for Review of studyspace

        form = SpaceReviewForm(data={
            'stars': 4,
            'message': "I love it!"
        })

        # check if form is valid entry
        assert form.is_valid()

        form.save_or_update_review(user, test_study_space)

        review = Review.objects.get(user=user, study_space=test_study_space)

        self.assertEqual(review.stars, 4)
        self.assertEqual(review.message, "I love it!")

        user2 = User.objects.create_user(username='test_user2', email='test_email2', password='1234562')

        test_study_space2 = StudySpace.objects.get(slug='davis-hall')

        form2 = SpaceReviewForm(data={
            'stars': 1,
            'message': "I hate it! So much!"
        })

        form2.save_or_update_review(user2, test_study_space2)

        review2 = Review.objects.get(user=user2, study_space=test_study_space2)

        self.assertEqual(review2.stars, 1)
        self.assertEqual(review2.message, "I hate it! So much!")

        # get review of studyspace by username - check if stars/message are correct

    def test_search(self):

        # making the user
        user = User.objects.create_user(username='test_user5', email='test_email5', password='123455')
        # the buildings the user wants
        buildings_selected = [Building.objects.get(name='Capen Hall'), Building.objects.get(name='Cooke Hall')]
        # making the user's form
        form = PreferencesForm(data={'prefers_libraries': True,
                                     'prefers_obscure_spaces': None,
                                     'prefers_silent_spaces': True,
                                     'buildings': buildings_selected})
        # check if form is valid entry
        assert form.is_valid()
        # save the preferences made in the form to the user
        form.save_user_preferences(user)

        # get the user's data
        u_p = UserPreferences.objects.get(user=user)

        filtered_spaces = search.search_study_spaces(u_p)

        expected = ["East Lounge, 3rd Floor", "Grand Reading Room 3rd Floor", "North Lounge 3rd Floor",
                    "Study Booths, 3rd Floor"]

        print("FILTERED SPACES")

        for i, j in zip(filtered_spaces, expected):
            print(i.name)
            self.assertEqual(i.name, j)

        # making the user
        user2 = User.objects.create_user(username='test_user6', email='test_email6', password='1234556')
        # the buildings the user wants
        buildings_selected2 = [Building.objects.get(name='Capen Hall'), Building.objects.get(name='Cooke Hall')]
        # making the user's form
        form2 = PreferencesForm(data={'prefers_libraries': True,
                                      'prefers_obscure_spaces': True,
                                      'prefers_silent_spaces': True,
                                      'buildings': buildings_selected2})
        # check if form is valid entry
        assert form2.is_valid()
        # save the preferences made in the form to the user
        form2.save_user_preferences(user2)

        # get the user's data
        u_p2 = UserPreferences.objects.get(user=user2)

        filtered_spaces2 = search.search_study_spaces(u_p2)

        expected2 = ["East Lounge, 3rd Floor", "Grand Reading Room 3rd Floor", "North Lounge 3rd Floor",
                     "Study Booths, 3rd Floor", "Cooke Hall"]

        print("SECOND GROUP OF FILTERED SPACES")

        for i, j in zip(filtered_spaces2, expected2):
            print(i.name)
            self.assertEqual(i.name, j)
