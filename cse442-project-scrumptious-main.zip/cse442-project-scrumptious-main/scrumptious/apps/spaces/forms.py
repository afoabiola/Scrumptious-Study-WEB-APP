from django import forms
from django.contrib.auth.models import User
from django.utils.html import strip_tags

from .models import Review, StudySpace, Feature
from ..preferences.models import Building


class SpaceReviewForm(forms.Form):
    stars = forms.IntegerField(min_value=1, max_value=5, required=True)
    message = forms.CharField(
        max_length=Review.MAX_MESSAGE_LENGTH,
        required=True,
        widget=forms.Textarea
    )

    def save_or_update_review(self, user, space):
        # type: (User, StudySpace) -> None

        self.is_valid()
        try:
            user_review = Review.objects.get(user=user, study_space=space)  # type: Review
        except Review.DoesNotExist:
            user_review = Review()
            user_review.user = user
            user_review.study_space = space

        stars = self.cleaned_data.get('stars')
        # while not strictly necessary thanks to Django escaping stuff when templating variables
        # this goes an extra step of making sure people realize their feeble attempt at tags won't
        # even persist
        message = strip_tags(self.cleaned_data.get('message'))

        assert type(stars) is int, 'Stars must be an integer!'
        assert 1 <= self.cleaned_data.get('stars') <= 5, 'Stars must be between 1 and 5!'
        assert len(message) <= Review.MAX_MESSAGE_LENGTH, 'Review body must not exceed max length!'

        user_review.stars = stars
        user_review.message = message

        user_review.save()


def space_search_suggestions():
    building_suggestions = [b.name for b in Building.objects.all()]
    feature_suggestions = [f.name for f in Feature.objects.all()]
    space_suggestions = [s.name for s in StudySpace.objects.all()]
    return building_suggestions + feature_suggestions + space_suggestions


class SpaceSearchForm(forms.Form):
    query = forms.CharField(required=False)
    latitude = forms.FloatField(widget=forms.HiddenInput(), required=False)
    longitude = forms.FloatField(widget=forms.HiddenInput(), required=False)

    def get_query(self):
        if self.is_valid():
            return self.cleaned_data['query'].strip()

    def get_geo(self):
        if self.is_valid():
            try:
                latitude = float(self.cleaned_data['latitude'])
                longitude = float(self.cleaned_data['longitude'])
                return latitude, longitude
            except TypeError:
                pass
        return None
