from geopy.distance import geodesic
from typing import List, Optional, Tuple

from scrumptious.apps.preferences.models import UserPreferences
from scrumptious.apps.spaces.models import StudySpace, Feature


def search_study_spaces(preferences, query=None, geo=None):
    # type: (UserPreferences, Optional[str], Optional[Tuple[float, float]]) -> List[StudySpace]
    """
    Search for study spaces
    :param preferences: the user's preferences
    :param query: search query (may be emtpy)
    :param geo: latitude and longitude
    :return: list of found study spaces
    """
    rejected_features = []
    if not preferences.prefers_libraries:
        rejected_features.append(Feature.objects.library())
    if not preferences.prefers_silent_spaces:
        rejected_features.append(Feature.objects.silent())
    if not preferences.prefers_obscure_spaces:
        rejected_features.append(Feature.objects.obscure())

    spaces = StudySpace.objects.exclude(features__in=rejected_features)

    # If not building preferences are set, show all
    buildings = preferences.buildings.all()
    if buildings:
        spaces = spaces.filter(building__in=buildings)

    # If query, filter several different ways, case insensitive
    if query:
        building_filter = spaces.filter(building__name__icontains=query)
        name_filter = spaces.filter(name__icontains=query)
        feature_filter = spaces.filter(features__name__icontains=query)
        spaces = building_filter | name_filter | feature_filter
        spaces = spaces.distinct()

    # Calculate distances, if possible
    if geo:
        for space in spaces:
            if space.geo:
                distance = geodesic(geo, space.geo)
                space.distance = distance.feet
                if distance.miles <= 0.25:
                    space.distance_text = str(round(distance.feet, 3)) + ' feet away'
                else:
                    space.distance_text = str(round(distance.miles, 2)) + ' miles away'
            else:
                space.distance = None
        spaces = sorted(spaces, key=lambda s: (not s.is_open, s.distance is None, s.distance))
    else:
        spaces = sorted(spaces, key=lambda s: (not s.is_open, s.name))

    return spaces
