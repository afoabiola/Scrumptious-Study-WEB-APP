from django.contrib import messages
from django.shortcuts import render, redirect

from form import CustomUserCreationForm
# https://overiq.com/django-1-10/django-creating-users-using-usercreationform/
from scrumptious.settings import cheshire_prefix


def register(request):
    if request.method == 'POST':
        f = CustomUserCreationForm(request.POST)
        if f.is_valid():
            f.save()
            messages.success(request, 'Account created successfully')
            return redirect(cheshire_prefix('')[:-1])
    else:
        f = CustomUserCreationForm()

    return render(request, 'registration.html', {'form': f})
