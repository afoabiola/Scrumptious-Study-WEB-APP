function initMap() {
    const options = {
        zoom: 15,
        center: {lat: 43.0008, lng: -78.7890}
    };

    const map = new google.maps.Map(document.getElementById("map"), options);

    function addMarkers(LatLONG) {
        const marker = new google.maps.Marker({
            position: LatLONG.coords,
            map: map
        });


        if (LatLONG.iconImage) {
            marker.setIcon(LatLONG.iconImage);
        }

        if (LatLONG.content) {
            const infoWindow = new google.maps.InfoWindow({
                content: LatLONG.content
            });

            marker.addListener('click', function () {
                infoWindow.open(map, marker);
            });
        }
    }

    $.getJSON('data', function (data) {
        data.forEach(function (marker) {
            addMarkers({
                coords: {
                    lat: marker.geo[0],
                    lng: marker.geo[1],
                },
                content: `<h1 >${marker.name}</h1><a href="${marker.url}">View details</a>`,
            })
        })
    })
}
