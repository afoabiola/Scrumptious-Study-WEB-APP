$(function () {
    const searchForm = $("form#search");
    const searchButton = searchForm.find("button[type='submit']");
    searchButton.click(function (event) {
        event.preventDefault();
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                $("#latitude").val(position.coords.latitude);
                $("#longitude").val(position.coords.longitude);
                searchForm.submit();
            }, function () {
                searchForm.submit()
            });
        } else {
            searchForm.submit();
        }
    });
});
