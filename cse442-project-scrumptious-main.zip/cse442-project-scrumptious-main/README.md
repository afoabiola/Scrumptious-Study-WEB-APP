# Scrumptious

Live website: https://www-student.cse.buffalo.edu/CSE442-542/2021-Spring/cse-442a/

ZenHub: https://app.zenhub.com/workspaces/scrumptious-6021dbeddfd67400154ba808/board

## Project description

We are creating an application that will give you the nearest study spaces in UB North Campus based on your current
location. This project will be a web application that the user will be able to access through any device.

## List of languages/tools

- Python 2.7
- Django
- MySQL on Oceanus

## Team members

- **Afo:** mainly neutral, would like to do more front end if possible
- **Ian:** Neutral
- **Umar:** mainly neutral, would like to do more back end if possible
- **Fahim:** mainly neutral, would like to do more back end if possible

## Development

Read the [Django 1.11 LTS docs](https://docs.djangoproject.com/en/1.11/) for information on working with Django and
running the local development server. Be sure to install all requirements in [requirements.txt](requirements.txt) and
use Python 2.7 not 3.

### Docker
1. Run `docker-compose up`
1. Run `docker-compose exec web python manage.py migrate` to create the database
1. You can visit `localhost:8080` for the website, and `localhost:8085` for phpMyAdmin

This method is subject to change as it currently uses 'password' as a default password.
While this is only to be used for local development, it could be better.

### Manual

1. Either by using Docker or directly installing it, set up a MySQL server on your local machine.
1. Create a new user and database for the project.
1. Copy `mysql.example.cnf` to `mysql.cnf`, and fill in `host` (likely localhost), `database`, `user`, and `password` 
1. Run `python2 manage.py migrate`

## Deployment

### First time setup

1. Connect to Cheshire via SSH
1. Change directory to the web root (`/web/CSE442-542/2021-Spring/cse-442a`)
1. Run `virtualenv -p python2 .env` in the web root
1. Activate the virtual environment via `source .env/bin/activate.csh`
1. Install the requirements in [requirements.txt](requirements.txt)
1. Copy over the project contents into the web root via SFTP
1. Create a symbolic link `site.wsgi` in the web root pointing to `scrumptious/wsgi.py`
1. Copy `mysql.example.cnf` to `mysql.cnf`, and fill in `user` and `password`
1. Run `python2 manage.py migrate`

## Future deployments

1. Connect to Cheshire via SFTP
1. Update the contents of the `scrumptious` folder in the web root
   (see the previous section)
1. Activate the virtual environment via `source .env/bin/activate.csh`
1. Run `python manage.py collectstatic` to populate the git ignored folder `static` for static files
1. Run `touch site.wsgi` for the server to notice the site has been updated
